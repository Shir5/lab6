package Exceptions;

public class HightException extends Exception{
    public HightException(String errorMessage) {
        super(errorMessage);
    }
}
