package Exceptions;

public class ProgramExceptions extends Exception{
    public ProgramExceptions (String errorMessage){
        super(errorMessage);
    }
}
