package Exceptions;

public class LocationException extends Exception{
    public LocationException(String errorMessage){
        super(errorMessage);
    }
}
