package collection;

public enum Color {
    RED,
    BLUE,
    YELLOW,
    ORANGE,
    WHITE;
}
