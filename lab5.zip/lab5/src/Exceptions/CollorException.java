package Exceptions;

public class CollorException extends Exception{
    public CollorException (String errorMessage){
        super(errorMessage);
    }
}
