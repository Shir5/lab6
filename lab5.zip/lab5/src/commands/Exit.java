package commands;

public class Exit {

    //public static void executor() {

      //  System.exit(0);

   // }


}
