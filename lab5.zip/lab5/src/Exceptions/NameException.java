package Exceptions;

public class NameException extends Exception{
    public NameException (String errorMessage){
        super(errorMessage);
    }

}
