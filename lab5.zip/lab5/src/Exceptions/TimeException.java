package Exceptions;

public class TimeException extends Exception{
    public TimeException(String errorMessage){
        super(errorMessage);
    }
}
