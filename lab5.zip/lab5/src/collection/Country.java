package collection;

public enum Country {
    UNITED_KINGDOM,
    GERMANY,
    ITALY,
    NORTH_KOREA,
    JAPAN;
}
