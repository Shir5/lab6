package Exceptions;

public class NationalityException extends Exception{
    public NationalityException(String errorMessage) {
        super(errorMessage);
    }
}
