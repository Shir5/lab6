package Exceptions;

public class WeightException extends Exception{
    public WeightException(String errorMessage) {
        super(errorMessage);
    }
}
