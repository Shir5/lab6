package Exceptions;

public class CoordinateExceptions extends Exception{
    public CoordinateExceptions (String errorMessage){
        super(errorMessage);
    }
}
