package Exceptions;

public class IdException extends Exception{
    public IdException(String errorMessage){
        super(errorMessage);
    }
}
