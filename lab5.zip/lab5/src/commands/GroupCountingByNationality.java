package commands;

public class GroupCountingByNationality {
}
